disease_solutions = {
    "Leaf Mold": """🟢 **Solution for Leaf Mold**:
- 💨 Ensure good air circulation around the plants.
- 🌿 Prune lower leaves regularly.
- 🚫 Avoid overhead watering.
- 🧴 Apply a copper-based fungicide if severe.
""",

    "Early Blight": """🟠 **Solution for Early Blight**:
- 🧼 Remove infected leaves immediately.
- 🔁 Practice crop rotation.
- 🧴 Use neem oil or chlorothalonil spray.
""",

    "Late Blight": """🔴 **Solution for Late Blight**:
- ⚠️ Remove and destroy infected plants.
- 💧 Improve drainage and airflow.
- 🧴 Use systemic fungicides like mancozeb.
""",

    "Healthy": """✅ **No Disease Detected**:
- 🪴 Your plant appears healthy!
- 🧽 Keep up with regular care.
- ☀️ Ensure sunlight and proper nutrition.
""",

    "Powdery Mildew": """⚪ **Solution for Powdery Mildew**:
- 🌬 Increase air circulation.
- 🌿 Remove affected leaves.
- 🧴 Spray with sulfur or potassium bicarbonate.
""",

    "Downy Mildew": """🟣 **Solution for Downy Mildew**:
- 🌤 Water plants in the morning.
- 🍃 Improve spacing and ventilation.
- 🧴 Use copper-based fungicide.
""",

    "Anthracnose": """🟤 **Solution for Anthracnose**:
- ✂️ Prune infected areas.
- 🧼 Clean fallen debris.
- 🧴 Apply chlorothalonil or copper sprays.
""",

    "Bacterial Wilt": """🧬 **Solution for Bacterial Wilt**:
- ❌ Remove infected plants immediately.
- 🚫 Avoid overhead irrigation.
- 🔁 Practice long-term crop rotation.
""",

    "Fusarium Wilt": """🧪 **Solution for Fusarium Wilt**:
- 🧼 Remove affected plants.
- 🌱 Use resistant varieties.
- 🧴 Apply bio-fungicides like Trichoderma.
""",

    "Verticillium Wilt": """🟠 **Solution for Verticillium Wilt**:
- 🚜 Rotate crops regularly.
- 🔥 Solarize soil before planting.
- 🧴 Consider soil treatments with beneficial fungi.
""",

    "Rust": """🧡 **Solution for Rust Disease**:
- 🧽 Remove infected leaves early.
- 🌞 Water early in the day.
- 🧴 Apply sulfur or myclobutanil sprays.
""",

    "Septoria Leaf Spot": """🟡 **Solution for Septoria Leaf Spot**:
- ✂️ Remove lower, infected leaves.
- 💨 Improve air circulation.
- 🧴 Use chlorothalonil or mancozeb.
""",

    "Cercospora Leaf Spot": """🟣 **Solution for Cercospora Leaf Spot**:
- 🍂 Collect and destroy debris.
- 🌾 Use resistant plant varieties.
- 🧴 Apply fungicides like thiophanate-methyl.
""",

    "Alternaria Leaf Spot": """⚫ **Solution for Alternaria Leaf Spot**:
- 🌱 Avoid dense planting.
- 🧴 Spray with azoxystrobin or mancozeb.
- ✂️ Remove infected foliage.
""",

    "Botrytis Blight": """🌫 **Solution for Botrytis Blight (Gray Mold)**:
- 💨 Ensure airflow and reduce humidity.
- ✂️ Remove infected parts promptly.
- 🧴 Use fungicides like iprodione.
""",

    "Sooty Mold": """🖤 **Solution for Sooty Mold**:
- 🧽 Wash leaves with mild soap and water.
- 🐜 Control sap-sucking insects (aphids, whiteflies).
- 🌿 Prune for better air circulation.
""",

    "Black Spot": """⚫ **Solution for Black Spot**:
- ✂️ Remove and destroy infected leaves.
- 🧴 Use neem oil or sulfur-based sprays.
- 💧 Water at the base, not on leaves.
""",

    "Bacterial Leaf Spot": """🧫 **Solution for Bacterial Leaf Spot**:
- 🧼 Sanitize tools regularly.
- 🌱 Plant resistant varieties.
- 🧴 Apply copper fungicides early.
""",

    "Gummy Stem Blight": """🟫 **Solution for Gummy Stem Blight**:
- ✂️ Remove diseased vines.
- 💧 Avoid overhead irrigation.
- 🧴 Use thiophanate-methyl spray.
""",

    "Blossom End Rot": """⚪ **Solution for Blossom End Rot**:
- 🧪 Ensure consistent watering.
- 🧂 Add calcium supplements.
- 🛑 Avoid excess nitrogen fertilizers.
""",

    "Root Rot": """🟤 **Solution for Root Rot**:
- 💧 Improve drainage in soil.
- 🪴 Repot with sterile soil.
- 🧼 Remove decayed roots.
""",

    "Canker": """🚫 **Solution for Canker Disease**:
- ✂️ Prune affected stems well below infection.
- 🧴 Apply copper fungicide to cuts.
- 🔁 Rotate crops annually.
""",

    "Scab": """🟡 **Solution for Plant Scab**:
- 🍂 Remove and destroy infected leaves/fruits.
- 🧴 Use sulfur or myclobutanil sprays.
- 🌧 Water at soil level only.
""",

    "Crown Gall": """👑 **Solution for Crown Gall**:
- 🪓 Remove infected plants entirely.
- 🧪 Disinfect tools with bleach.
- ⛔ Avoid wounding stems/roots during planting.
""",

    "Mosaic Virus": """🧬 **Solution for Mosaic Virus**:
- ❌ Remove infected plants promptly.
- 🧫 Control insect vectors (aphids, beetles).
- 🔬 Use virus-free seeds.
""",

    "Yellow Leaf Curl": """💛 **Solution for Yellow Leaf Curl Virus**:
- 🐜 Control whitefly populations.
- 🌱 Use virus-resistant cultivars.
- 🧴 Insecticidal soaps may help reduce vectors.
""",

    "Bacterial Canker": """💉 **Solution for Bacterial Canker**:
- ✂️ Prune in dry weather.
- 🧪 Use copper-based bactericides.
- 🚿 Sanitize all pruning tools.
""",

    "Wilt": """🥀 **General Solution for Wilting**:
- 🌊 Check for over/under-watering.
- 🧫 Inspect for root disease or nematodes.
- 🌱 Use healthy soil and rotate crops.
""",

    "Sclerotinia Rot": """🍄 **Solution for Sclerotinia (White Mold)**:
- 💨 Increase airflow, avoid wet foliage.
- 🔥 Remove and burn infected material.
- 🧴 Apply fungicides with boscalid.
""",

    "Charcoal Rot": """🪵 **Solution for Charcoal Rot**:
- 🌱 Plant resistant varieties.
- 🔁 Rotate with non-host crops.
- 💧 Avoid water stress in hot weather.
""",

    "Pythium Rot": """🦠 **Solution for Pythium Root Rot**:
- 💧 Improve soil drainage.
- 🌱 Use sterilized soil.
- 🧴 Apply metalaxyl-based fungicide.
""",

    "Nematode Damage": """🪱 **Solution for Nematode Damage**:
- 🌱 Use nematode-resistant varieties.
- 🔁 Rotate crops.
- 🌿 Add organic compost to encourage microbes.
""",

    "Algal Leaf Spot": """🌊 **Solution for Algal Leaf Spot**:
- ✂️ Prune infected areas.
- 🧴 Use copper fungicide.
- ☀️ Ensure full sun exposure.
""",

    "Citrus Greening": """🍊 **Solution for Citrus Greening**:
- 🐞 Control psyllid vectors.
- 🧪 Remove infected trees.
- 🌱 Use certified disease-free planting material.
""",

    "Bacterial Blight": """🦠 **Solution for Bacterial Blight**:
- 🧼 Sanitize tools and equipment.
- 🌾 Use resistant cultivars.
- 🧴 Apply copper sprays during early infection.
""",

    "Sunscald": """☀️ **Solution for Sunscald**:
- 🌿 Provide shade cloth or windbreaks.
- 💧 Ensure proper hydration.
- ✂️ Avoid heavy pruning during hot seasons.
""",

    "Tip Burn": """🔥 **Solution for Tip Burn**:
- 💦 Maintain even soil moisture.
- 🧂 Use calcium-enriched fertilizer.
- ❄️ Avoid heat stress in leafy greens.
""",

    "Blight": """☣️ **General Solution for Blight**:
- ✂️ Prune infected parts immediately.
- 🌬 Increase ventilation.
- 🧴 Apply appropriate fungicides early.
"""
}
