import os
import re
from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
from PIL import Image, UnidentifiedImageError
import google.generativeai as genai
from disease_data import disease_solutions  # Import your predefined solutions

# Initialize Flask app
app = Flask(__name__)

# Upload folder config
UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Gemini API config
API_KEY = "AIzaSyCrY4kh8ir_luOoMepG1QUYSwKQsYIucG4"
genai.configure(api_key=API_KEY)

# Allowed file extensions
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def format_response(response_text):
    clean_text = re.sub(r"[*_#`~\-]", "", response_text)

    plant_name, disease_name, causes, solutions = "N/A", "N/A", "N/A", "N/A"

    plant_match = re.search(r"(?:Plant|Species|Tree|Leaf) Name[:\s]+(.+?)(?:\n|$)", clean_text, re.IGNORECASE)
    disease_match = re.search(r"(?:Disease|Infection) Name[:\s]+(.+?)(?:\n|$)", clean_text, re.IGNORECASE)
    causes_match = re.search(r"(?:Causes|Reasons)[:\s]+(.+?)(?:\n|$)", clean_text, re.IGNORECASE)
    solutions_match = re.search(r"(?:Solutions|Treatment|Care Tips)[:\s]+(.+?)(?:\n|$)", clean_text, re.IGNORECASE)

    if plant_match:
        plant_name = plant_match.group(1).strip()
    if disease_match:
        disease_name = disease_match.group(1).strip()
    if causes_match:
        causes = causes_match.group(1).strip()
    if solutions_match:
        solutions = solutions_match.group(1).strip()

    return {
        "plant_name": plant_name,
        "disease_name": disease_name,
        "causes": causes,
        "solutions": solutions
    }

def predict_disease(image_path):
    model = genai.GenerativeModel("gemini-1.5-pro")
    try:
        with Image.open(image_path) as img:
            prompt = """
            Identify the plant species, detect any disease, and provide the following details:

            Plant Name: 
            Disease Name: 
            Causes: 
            Solutions: 

            Ensure the information is clear and separated by these headings.
            """
            response = model.generate_content([prompt, img])
            return format_response(response.text)
    except (IOError, UnidentifiedImageError):
        return {"plant_name": "N/A", "disease_name": "N/A", "causes": "N/A", "solutions": "N/A"}

@app.route("/", methods=["GET", "POST"])
def upload_file():
    if request.method == "POST":
        if "file" not in request.files:
            return "No file uploaded."

        file = request.files["file"]
        if file.filename == "":
            return "No file selected."

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)

            # Predict
            result = predict_disease(filepath)

            # Try to use predefined solution first
            user_disease = result["disease_name"].lower()
            for known_disease, solution in disease_solutions.items():
                if known_disease.lower() in user_disease:
                    result["solutions"] = solution
                    break  # Use the first match

            return render_template("result.html", image_url=filepath, result=result)

        else:
            return "Invalid file type. Please upload an image (png, jpg, jpeg, gif)."

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
